﻿using Microsoft.EntityFrameworkCore;
using EpikApiPersona.Models;
namespace EpikApiPersona.Context
{
    public class PersonaDbContext : DbContext
    {
        public DbSet<Persona> Persona { get; set; }
        public PersonaDbContext(DbContextOptions<PersonaDbContext> options)
        : base(options)
        {
        }
    }
}
