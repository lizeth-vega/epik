﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EpikApiPersona.Context;
using EpikApiPersona.Models;
using Microsoft.Data.SqlClient;

namespace EpikApiPersona.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonasController : ControllerBase
    {
        private readonly PersonaDbContext _context;

        public PersonasController(PersonaDbContext context)
        {
            _context = context;
        }

        // GET: ALL api/Personas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Persona>>> GetPersona()
        {
            return await _context.Persona.ToListAsync();
        }

        // GET: BY ID api/Personas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Persona>> GetPersona(int id)
        {
            var persona = await _context.Persona.FindAsync(id);

            if (persona == null)
            {
                return NotFound();
            }

            return persona;
        }


        // POST: api/Personas
        [HttpPost]
        public async Task<ActionResult<Persona>> PostPersona(Persona persona)
        {
            // Validar el valor del campo Género
            if (persona.Genero != "Femenino" && persona.Genero != "Masculino")
            {
                return BadRequest("El valor del campo 'Genero' debe ser 'Femenino' o 'Masculino'.");
            }

            try
            {
                // Agregar la persona al contexto
                _context.Persona.Add(persona);
                await _context.SaveChangesAsync();

                // Retornar la respuesta con la persona creada
                return CreatedAtAction("GetPersona", new { id = persona.Identificacion }, persona);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Se ha producido un error en el servidor. Intente de nuevo más tarde.");

            }
        }

        // DELETE: api/Personas/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePersona(int id)
        {
            var persona = await _context.Persona.FindAsync(id);
            if (persona == null)
            {
                return NotFound();
            }

            _context.Persona.Remove(persona);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpGet("mujeres")]
        public async Task<ActionResult<IEnumerable<Persona>>> GetMujeres()
        {
            var mujeres = await _context.Persona.Where(p => p.Genero == "Femenino").ToListAsync();

            if (mujeres == null || !mujeres.Any())
            {
                return NotFound();
            }

            return Ok(mujeres);
        }
        
        [HttpPut("{id}/edad")]
        public async Task<IActionResult> ActualizarEdad(int id, [FromBody] int nuevaEdad)
        {
            // Buscar la persona por su ID
            var persona = await _context.Persona.FindAsync(id);

            // Si no se encuentra, retorna 404 (Not Found)
            if (persona == null)
            {
                return NotFound();
            }

            // Actualizar la edad de la persona
            persona.Edad = nuevaEdad;

            // Guardar los cambios en la base de datos
            await _context.SaveChangesAsync();

            // Retornar la persona actualizada
            return Ok(persona);
        }

        private bool PersonaExists(int id)
        {
            return _context.Persona.Any(e => e.Identificacion == id);
        }
    }
}
