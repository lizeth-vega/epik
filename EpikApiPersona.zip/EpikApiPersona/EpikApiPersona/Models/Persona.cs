﻿using System.ComponentModel.DataAnnotations;

namespace EpikApiPersona.Models
{
    public class Persona
    {
        [Key]
        public int Identificacion { get; set; }
        public string Nombres { get; set; } = null!;

        public string Apellidos { get; set; } = null!;

        public int? Edad { get; set; }

        public string? Genero { get; set; }
    }
}
